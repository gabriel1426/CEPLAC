// G2
declare var G2: any;
declare var DataSet: any;
declare var Slider: any;
